#include <iostream>
using namespace std;
int main ()
{
    int n,m;
    cin>>n>>m;
    int n2=n/2;
    int m2=m/2;
    int mas1[n][m];
    int mas2[n2][m2];
    for (int i=0;i<n;i++)
        for (int j=0;j<m;j++)
        {
            int vvod;
            cin>>vvod;
            if ((i<n2)&&(j<m2))
            {
                mas2[i][j]=vvod;
            }
            mas1[i][j]=vvod;
        }

    int n2d=n2;
    int m2d=m2;
    if (n%2!=0)
    {
        n2d++;
    }
    if (m%2!=0)
    {
        m2d++;
    }
    for (int i=0;i<n2;i++)
        for (int j=0;j<m2;j++)
        {
            mas1[i][j]=mas1[i+n2d][j+m2d];
            mas1[i+n2d][j+m2d]=mas2[i][j];
        }
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<m;j++)
        {
            cout<<mas1[i][j]<<' ';
        }
        cout<<endl;
    }
    /*
    for (int i=0;i<n2;i++)
    {
        for (int j=0;j<m2;j++)
        {
            cout<<mas2[i][j]<<' ';
        }
        cout<<endl;
    }
    */

}
