#include <iostream>
#include <cmath>
#include <vector>
#include<stdio.h>
using namespace std;
int main ()
{
    int n;
    cin>>n;
    int mas[n][n];
    vector <float> vect;
    for (int i=0;i<n;i++)
    {
        int vvod;
        cin>>vvod;
        vect.push_back(abs(vvod));
        mas[0][i]=vvod;
    }
    for (int i=1;i<n;i++)
        for (int j=0;j<n;j++)
        {
            int vvod;
            cin>>vvod;
            vect[j]=vect[j]+abs(vvod);
            mas[i][j]=vvod;
        }
    float mincr=vect[0];
    int st=0;
    for (int i=1;i<n;i++)
    {
        if (vect[i]<mincr)
        {
            mincr=vect[i];
            st=i;
        }
    }
    st++;
    mincr=mincr/n;
    cout<<st<<endl<<fixed;
    cout.precision(4);
    cout<<mincr;
}
