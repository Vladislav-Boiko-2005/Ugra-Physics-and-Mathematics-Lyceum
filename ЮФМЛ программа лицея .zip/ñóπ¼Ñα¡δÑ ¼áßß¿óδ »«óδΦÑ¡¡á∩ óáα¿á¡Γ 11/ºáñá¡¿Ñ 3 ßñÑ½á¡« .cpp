#include <iostream>
using namespace std;
int main ()
{
    int n=19;
    int m=11;
    int in=0;
    int k;
    float mas[n][m];
    while (in<1)
    {
        cin>>k;
        if ((1<k)&&(k<m-1))
        {
            in++;
        }
    }
    for (int i=0;i<n;i++)
        for (int j=0;j<m;j++)
        {
            float vvod;
            cin>>vvod;
            mas[i][j]=vvod;
        }

    int chet=0;
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<m;j++)
        {
            if (i>=k)
            {
                mas[i-k][j]=mas[i][j];
            }
        }
        if (i<k)
        {
            chet++;
        }
    }
    //cout<<chet<<endl;
    for (int i=0;i<chet;i++)
        for (int j=0;j<m;j++)
        {
            mas[n-i-1][j]=0;
        }
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<m;j++)
        {
            cout<<mas[i][j]<<' ';
        }
        cout<<endl;
    }
}
