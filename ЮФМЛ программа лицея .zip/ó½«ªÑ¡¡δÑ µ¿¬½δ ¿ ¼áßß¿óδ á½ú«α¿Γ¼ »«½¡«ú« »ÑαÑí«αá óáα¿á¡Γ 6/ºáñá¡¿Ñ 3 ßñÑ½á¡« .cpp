#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
int main ()
{
    vector <float> x;
    vector <float> y;
    vector <float> r;
    int n=10;
    for (int i=0;i<n;i++)
    {
        float vv1,vv2,vv3;
        cin>>vv1>>vv2>>vv3;
        x.push_back(vv1);
        y.push_back(vv2);
        r.push_back(vv3);
    }
    for (int i=0;i<n;i++)
    {
        for (int j=1;j<n;j++)
        {
            float razx=(x[i]-x[j])*(x[i]-x[j]);
            float razy=(y[i]-y[j])*(y[i]-y[j]);
            float raz= sqrtf (razx + razy);
            if (r[i]+r[j]>raz)
            {
                cout<<i+1;
                return 0;
            }
        }
    }
    cout<<"No";
}
