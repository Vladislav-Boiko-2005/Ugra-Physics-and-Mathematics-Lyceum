#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    vector <int> vect;
    int n=10;
    int chet=0;
    for (int i=0;i<n;i++)
    {
        int vvod;
        cin>>vvod;
        if (vvod==0)
        {
            chet++;
        }
        else
        {
            vect.push_back(vvod);
            cout<<vvod<<' ';
        }
    }
    for (int i=0;i<chet;i++)
    {
        cout<<0<<' ';
    }
}
