#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    int n=4;
    int i=0;
    vector <int> vect;
    while (i<n)
    {
        int vvod;
        cin>>vvod;
        if ((vvod>9)&&(vvod<21))
        {
            vect.push_back(vvod);
            i++;
        }
        else
        {
            cout<<"error"<<endl;
        }
    }
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<n-i-1;j++)
        {
            if (vect[j]>vect[j+1])
            {
                int prom=vect[j+1];
                vect[j+1]=vect[j];
                vect[j]=prom;
            }
        }
    }
    int chet=0;
    if (vect[0]!=vect[1])
    {
        chet++;
    }
    vect.push_back(0);
    for (int i =0;i<n-1;i++)
    {
        if ((vect[i]!=vect[i+1])&&(vect[i+1]!=vect[i+2]))
        {
            chet++;
        }
    }
    cout<<chet;
}
