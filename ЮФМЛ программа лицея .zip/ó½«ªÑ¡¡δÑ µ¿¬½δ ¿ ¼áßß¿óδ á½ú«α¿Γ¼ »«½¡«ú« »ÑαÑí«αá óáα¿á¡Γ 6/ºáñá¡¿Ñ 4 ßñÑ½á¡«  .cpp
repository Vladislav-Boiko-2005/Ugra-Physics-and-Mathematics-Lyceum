#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
int main ()
{
    int n=3;
    int mas[1][n-1];
    vector <float> vectx;
    vector <float> vecty;
    vector <float> vectr;
    for (int i=0;i<n;i++)
    {
        float vvod;
        cin>>vvod;
        vectx.push_back(vvod);
    }
    for (int i=0;i<n;i++)
    {
        float vvod;
        cin>>vvod;
        vecty.push_back(vvod);
    }
    for (int i=1;i<n;i++)
    {
        float x=(vectx[i]-vectx[0])*(vectx[i]-vectx[0]);
        float y=(vecty[i]-vecty[0])*(vecty[i]-vecty[0]);
        float minr=sqrt(x+y);
        for (int j=0;j<n;j++)
        {
            if(j!=i){
                x=(vectx[i]-vectx[j])*(vectx[i]-vectx[j]);
                y=(vecty[i]-vecty[j])*(vecty[i]-vecty[j]);
                float raz=sqrt(x+y);
                if (raz<minr)
                {
                    minr=raz;
                }
            }
        }
        vectr.push_back(minr);
        //cout<<minr<<endl;
    }
    float minh=vectr[0];
    int index=0;
    for (int i=0;i<n;i++)
    {
        if (vectr[i]<minh)
        {
            minh=vectr[i];
            index=i;
        }
    }
    cout<<index;

}
