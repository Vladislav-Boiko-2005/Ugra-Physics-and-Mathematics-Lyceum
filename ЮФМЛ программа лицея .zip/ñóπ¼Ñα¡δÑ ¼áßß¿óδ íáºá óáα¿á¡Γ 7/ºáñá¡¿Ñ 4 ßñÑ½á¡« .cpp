#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    int n;
    cin>>n;
    char mas[n][n];
    for (int i=0;i<n;i++)
        for (int j=0;j<n;j++)
        {
            int vvod;
            cin>>vvod;
            mas[i][j]=vvod;
        }
    int raz=n/2;
    for (int  i=0;i<raz;i++)
        for (int j=0;j<i;j++)
        {
            mas[i][j]=' ';
            mas[n-i][j]=' ';
            mas[i][n-j]=' ';
            mas[n-i][n-j]=' ';
        }
    if (n%2!=0)
    {
        for (int i=0;i<raz;i++)
        {
            mas[raz+1][i]=' ';
            mas[raz+1][n-i]=' ';
        }
    }
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<n;j++)
        {
            cout<< mas[i][j]<<' ';
        }
        cout<<endl;
    }
}
