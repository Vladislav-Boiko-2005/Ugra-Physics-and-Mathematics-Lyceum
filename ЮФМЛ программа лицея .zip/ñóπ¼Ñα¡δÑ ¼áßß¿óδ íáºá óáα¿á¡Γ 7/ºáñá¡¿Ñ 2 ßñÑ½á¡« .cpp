#include <iostream>
using namespace std;
int main ()
{
    int n,m;
    cin>>n>>m;
    int mas[n][m];
    int sum=0;
    for (int i=0;i<n;i++)
    for (int j=0;j<m;j++)
    {
        int vvod;
        cin>>vvod;
        mas[i][j]=vvod;
    }
    int mn=m/2;
    if (m%2!=0)
    {
        mn++;
    }
    for (int i=0;i<n/2;i++)
    for (int j=mn;j<m;j++)
    sum=sum+mas[i][j];
    cout<<sum;
}
