#include <iostream>
using namespace std;
int mas[11][11];
int maxhis (int h,int n, int m)
{
    int maxh=mas[0][h];
    for (int i=0;i<n;i=i+2)
    for (int j=h;j<m;j++)
    {
        if (mas[j][i]>maxh)
        {
            maxh=mas[j][i];
        }
    }
    return maxh;
}
int main()
{
    int n,m;
    cin>>n>>m;
    for (int i=0;i<n;i++)
    for (int j=0;j<m;j++)
    {
        int vvod;
        cin>>vvod;
        mas[i][j]=vvod;
    }
    int mh=maxhis(1,n,m);
    int mnh=maxhis(0,n,m);
    if (mh==mnh)
    {
        cout<<0;
        return 0;
    }
    if (mh>mnh)
    {
        cout<<1;
        return 0;
    }
    else
    {
        cout<<-1;
        return 0;
    }
}
