#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    vector <int> vect;
    int sum=0;
    for (int i=0;i<10;i++)
    {
        int vvod;
        cin>>vvod;
        if ((vvod>9)&&(vvod<21))
        {
            vect.push_back(vvod-sum);
            cout<<sum<<endl;
            sum=sum+vvod;
        }
        else
        {
            cout<<"error";
            return 0;
        }
    }
    for (int i=0;i<10;i++)
    {
        cout<<vect[i]<<' ';
    }
}
