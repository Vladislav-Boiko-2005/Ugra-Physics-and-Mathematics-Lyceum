#include <iostream>
#include <string>

using namespace std;

int to_10_sistem(string h_proh, int star_osnov){
    int new_h=0;
    for (int i=h_proh.size()-1;i>-1;i--){
        if (h_proh[i]>'9'){
            if (h_proh[i]-'A'+10>=star_osnov){
                cout<<"error znah vvod new snah and new osnov"<<'\n';
                new_h=0;
                cin>>h_proh>>star_osnov;
            }
            else {
                    new_h=(h_proh[i]-'A'+10)+new_h*10;
            }
        }
        else {
            if (h_proh[i]-'0'>=star_osnov){
                cout<<"error znah vvod new snah and new osnov"<<'\n';
                new_h=0;
                cin>>h_proh>>star_osnov;
            }
            else {
                new_h=(h_proh[i]-'0')+new_h*10;
            }
        }
    }
    return new_h;
}

int to_new_sistem (int h, int new_sistem){
    int step_10=1;
    int new_h=0;
    int cel_del=h;
    while(cel_del!=0){
        new_h+=(cel_del%new_sistem)*step_10;
        step_10*=10;
        cel_del/=new_sistem;
    }
    return new_h;
}

int main (){
    string n;
    int osnov1, osnov2;
    cin>>n>>osnov1>>osnov2;
    int ten_sistem=to_10_sistem(n,osnov1);
    int new_h=to_new_sistem(ten_sistem, osnov2);
    cout<<new_h<<'\n';
}
