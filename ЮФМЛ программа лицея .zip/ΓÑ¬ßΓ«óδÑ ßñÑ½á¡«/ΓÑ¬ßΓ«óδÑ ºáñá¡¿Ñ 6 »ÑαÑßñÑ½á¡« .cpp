#include <fstream>
#include <time.h>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
int main ()
{
    ofstream file;
    string put_to_file="zadanie_6.txt";
    file.open(put_to_file);
    int n,k;
    cin>>n>>k;
    srand(time(NULL));
    file<<n<<' '<<k<<'\n';
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<k;j++)
        {
            int h=rand()%5+1;
            file<<h<<' ';
        }
        file<<'\n';
    }
    file.close();
    string str;
    int sum_obh=0;
    int sum_fiz=0;
    ifstream file_to_chit;
    file_to_chit.open(put_to_file);
    getline(file_to_chit, str);
    cout<<str<<'\n';
    vector <int> vect_sum_str;
    while(getline(file_to_chit, str))
    {
        sum_fiz+= int(str[2])-48;
        int sum_str=0;
        for (int i=0;i<str.size();i=i+2)
            sum_str+=int(str[i])-48;
        vect_sum_str.push_back(sum_str);
        sum_obh+=sum_str;
        cout<<str<<'\n';
    }
    int chet_people=0;
    for (int i=0;i<vect_sum_str.size();i++)
    {
            if (float ((vect_sum_str[i]/n)<=(0.75*sum_obh/(n*k))))
                chet_people++;
    }
    float cr_fiz=(float)(sum_fiz/n);
    cout<<"bal po fizike "<<cr_fiz<<'\n'<<"uheneci menihe na 25% "<<chet_people<<'\n';
    file_to_chit.close();
}
