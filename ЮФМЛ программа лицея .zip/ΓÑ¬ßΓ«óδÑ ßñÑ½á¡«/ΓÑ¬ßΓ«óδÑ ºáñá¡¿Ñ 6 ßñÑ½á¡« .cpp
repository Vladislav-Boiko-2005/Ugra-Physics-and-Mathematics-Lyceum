#include <fstream>
#include <time.h>
#include <iostream>
#include <string>
using namespace std;
int main ()
{
    ofstream file;
    string put_to_file="zadanie_6.txt";
    file.open(put_to_file);
    int n,k;
    cin>>n>>k;
    srand(time(NULL));
    file<<n<<' '<<k<<'\n';
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<k;j++)
        {
            int h=rand()%5+1;
            file<<h<<' ';
        }
        file<<'\n';
    }
    file.close();
    string str;
    int sum_obh=0;
    int sum_fiz=0;
    ifstream file_to_chit;
    file_to_chit.open(put_to_file);
    getline(file_to_chit, str);
    cout<<str;
    string proh_str="";
    while(getline(file_to_chit, str))
    {
        sum_fiz+= int(str[2])-48;
        int sum_str=0;
        for (int i=0;i<str.size();i=i+2)
            sum_str+=int(str[i])-48;
        file.open(put_to_file, ofstream ::app);
        file<<sum_str<<' ';
        sum_obh+=sum_str;
        file.close();
        cout<<proh_str<<'\n';
        proh_str=str;
    }
    int sum_otmet_human=0;
    int chet_people=0;
    for (int i=0;i<str.size();i++)
    {
        if (str[i]==' ')
        {
            if (float ((sum_otmet_human/(k*n))==(0.75*sum_obh/(n*k))))
                chet_people++;
            sum_otmet_human=0;
        }
        else
        sum_otmet_human=sum_otmet_human*10+int(str[i])-48;
    }
    float cr_fiz=(float)(sum_fiz-(int(str[2])-48))/n;
    cout<<"bal po fizike "<<cr_fiz<<'\n'<<"uheneci menihe na 25% "<<chet_people<<'\n';
    file_to_chit.close();
}
