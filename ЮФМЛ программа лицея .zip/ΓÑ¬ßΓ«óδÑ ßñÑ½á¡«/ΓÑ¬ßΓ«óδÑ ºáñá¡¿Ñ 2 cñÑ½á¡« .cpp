#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
using namespace std;
int main ()
{
    int n;
    srand (time(NULL));
    int nmin=10;
    int nmax=60;
    n=rand()%(nmax-nmin+1)+nmin;
    cout<<"n raven "<<n<<'\n';
    int h;
    int hmin=34;
    int hmax=76;
    string put_file="zadanie 2.txt";
    ofstream file;
    file.open(put_file);
    for (int i=0;i<n;i++)
    {
        h=rand()%(hmax-hmin+1)+hmin;
        file<<h<<'\n';
    }
    file.close();
    n=n/5;
    file.open(put_file,ios::app);
    for (int i=0;i<n;i++)
    {
        h=rand()%(hmax-hmin+1)+hmin;
        file<<h<<'\n';
    }
    file.close();
    ifstream file_chit;
    string s;
    file_chit.open(put_file);
    while (getline(file_chit,s))
    {
        cout<<s<<'\n';
    }
}
