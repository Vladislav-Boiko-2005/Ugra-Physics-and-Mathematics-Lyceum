#include <iostream>
#include <fstream>
#include <string>
#include <time.h>
using namespace std;
int main ()
{
    system("chcp 1251>nul");
    string podstr="";
    for (int i=0;i<5;i++)
    {
        int k=rand()%(123-47)+47;
        podstr.push_back(k);
    }
    cout<<"��������� "<<podstr<<'\n';
    ofstream file;
    string name="zadanie_1.txt";
    file.open(name);
    srand(time(NULL));;
    int n=rand()%10+5;
    for (int i=0;i<n;i++)
    {
        int d=rand()%15+10;
        int line=0;
        string str="";
        while (line<d)
        {
            int k=rand()%(123-47)+47;
            str.push_back(char(k));
            line=str.size();
        }
        file<<str;
        file<<'\n';
    }
    file.close();
    ifstream chit_file;
    chit_file.open(name);
    string s;
    while (getline (chit_file,s))
        cout<<s<<'\n';
    chit_file.close();
    chit_file.open(name);
    while (getline (chit_file,s))
        {
            for (int i=0;i<s.size();i++)
            {
                if (podstr[0]==s[i])
                {
                    bool sovp=1;
                    for (int j=1;j<podstr.size();j++)
                    {
                        if (podstr[j]!=s[i+j])
                            sovp=0;
                    }
                    if (sovp==1)
                    {
                        cout<<1<<'\n';
                        return 0;
                    }
                }
            }
        }
        cout<<0<<'\n';
        return 0;
    chit_file.close();

}
