#include <fstream>
#include <time.h>
#include <iostream>
#include <string>
using namespace std;
int main ()
{
    ofstream file;
    string put_to_file="zadanie_5.txt";
    file.open(put_to_file);
    int nmin=1;
    int nmax=15;
    int kol_otmet=4;
    srand(time(NULL));
    int n=rand()%(nmax-nmin+1)+nmin;
    file<<n<<'\n';
    for (int i=1;i<=n;i++)
    {
        file<<"famile"<<i<<' '<<"name"<<i<<' ';
        for (int j=0;j<kol_otmet;j++)
        {
            int h=rand()%4+2;
            file<<h<<' ';
        }
        file<<'\n';
    }
    file.close();
    ifstream file_chit;
    file_chit.open(put_to_file);
    string str;
    while (getline(file_chit,str))
        cout<<str<<'\n';
    file_chit.close();
    file_chit.open(put_to_file);
    getline(file_chit,str);
    int chet_3=0;
    cout<<"troihniki"<<'\n';
    while (getline(file_chit,str))
    {
        int flag=0;
        for (int i=0;i<kol_otmet*2;i++)
        {
            if (str[str.size()-i]=='3')
                flag++;
        }
        if (flag==1)
        {
            chet_3++;
            for (int i=0;i<str.size()-kol_otmet*2;i++)
            {
                cout<<str[i];
            }
            cout<<'\n';
        }
    }
    cout<<"1_trica "<<chet_3;
    file_chit.close();
}
