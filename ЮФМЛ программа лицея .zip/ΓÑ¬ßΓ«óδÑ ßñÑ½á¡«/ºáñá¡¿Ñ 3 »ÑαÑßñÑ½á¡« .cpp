#include <fstream>
#include <time.h>
#include <iostream>
using namespace std;
int main ()
{
    int nmin=3;//*3
    int nmax=5;//*3
    srand(time(NULL));
    int n=(rand()%(nmax-nmin+1)+nmin)*3;
    string put_to_file="zadanie_3.txt";
    ofstream file;
    file.open(put_to_file);
    int lineh=9;
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<lineh;j++)
        {
            int h=rand()%10;
            file<<h;
        }
        file<<'\n';
    }
    file.close();
    ifstream file_chit;
    file_chit.open(put_to_file);
    string s;
    int chet_3=1;
    char max_troica='.';
    while (getline(file_chit,s))
    {
        for (int i=0;i<s.size()-2;i++)
        {
            if (s[i]==s[i+1]&&s[i]==s[i+2])
            {
                if (max_troica==s[i])
                {
                    max_troica= s[i];
                    chet_3++;
                }
                else
                {
                    chet_3=1;
                    if (s[i]>max_troica)
                    {
                        max_troica=s[i];
                    }
                }
            }
        }
        cout<<s<<'\n';
    }
    if (max_troica!='.')
    {
        cout<<"max_troica "<<max_troica<<max_troica<<max_troica<<'\n'<<chet_3<<'\n';
        return 0;
    }
    cout<<"No";
    return 0;
    file_chit.close();
}
