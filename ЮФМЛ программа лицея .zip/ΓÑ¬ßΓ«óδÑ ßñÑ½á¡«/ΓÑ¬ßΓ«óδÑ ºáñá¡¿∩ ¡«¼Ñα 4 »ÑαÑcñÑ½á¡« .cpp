#include <fstream>
#include <time.h>
#include <iostream>
#include <string>
using namespace std;
int main ()
{
    ofstream file;
    string put_to_file="dano.txt";
    file.open(put_to_file);
    int nmax=10;
    int nmin=5;
    srand(time(NULL));
    int n=rand()%(nmax-nmin)+nmin;
    file<<n<<'\n';
    int hmax=100;
    int hmin=1;
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<3;j++)
        {
            int h=rand()%(hmax-hmin)+hmin;
            file<<h<<' ';
        }
        file<<'\n';
    }
    file.close();
    ifstream file_chit;
    file_chit.open(put_to_file);
    string str;
    int chet_true=0;
    while(getline(file_chit,str))
        cout<<str<<'\n';
    file_chit.close();
    file_chit.open(put_to_file);
    getline(file_chit,str);
    int chet_triugol=0;
    int index=0;
    while (getline(file_chit,str))
    {
        int storon[3]={0,0,0};
        int chet_prob=0;
        for (int i=0;i<str.size();i++)
        {
            if (str[i]==' ')
                chet_prob++;
            else
            {
                storon[chet_prob]=storon[chet_prob]*10+int(str[i]);//��������� �� �������� � int
            }
        }
        bool rez=1;
        if (storon[0]>storon[1]+storon[2])
            rez=0;
        if (storon[1]>storon[2]+storon[0])
            rez=0;
        if (storon[2]>storon[0]+storon[1])
            rez=0;
        if (rez==1)
            chet_triugol++;
        index++;
        cout<<index<<") "<<rez<<'\n';
    }
    file_chit.close();
    cout<<"triugol "<<chet_triugol<<'\n';
}
