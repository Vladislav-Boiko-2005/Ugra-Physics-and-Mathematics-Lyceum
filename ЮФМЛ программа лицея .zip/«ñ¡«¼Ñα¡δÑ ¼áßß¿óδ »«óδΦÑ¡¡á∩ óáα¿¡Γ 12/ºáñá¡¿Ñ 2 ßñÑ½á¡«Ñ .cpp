#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    vector <int> vect;
    int chet=0;
    for (int i=0;i<10;i++)
    {
        int vvod;
        cin>>vvod;
        if ((vvod>-1)&&(vvod<6))
        {
            if (vvod==0)
            {
                chet++;
            }
            else
            {
                vect.push_back(vvod);
            }
        }
        else
        {
            cout<<"error";
            return 0;
        }
    }
    for (int i=0;i<chet;i++)
    {
        vect.push_back(0);
    }
    for (int i=0;i<vect.size();i++)
    {
        cout<<vect[i]<<' ';
    }
}
