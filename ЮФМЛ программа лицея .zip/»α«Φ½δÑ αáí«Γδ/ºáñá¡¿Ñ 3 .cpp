#include <iostream>
using namespace std;
int main()
{
	int x, y, z;
	cin >> x >> y >> z;
	float ot = ((x * 500 + y + z * 10) / 500) * 1.0668 * 1000;
	cout << ot;
	return 0;
}