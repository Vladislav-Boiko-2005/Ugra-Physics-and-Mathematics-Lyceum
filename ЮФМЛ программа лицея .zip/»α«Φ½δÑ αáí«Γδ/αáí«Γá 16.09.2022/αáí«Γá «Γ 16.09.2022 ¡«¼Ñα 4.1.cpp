#include <iostream>
using namespace std;
int main ()
{
    int x,y;
    cin>> x>>y;
    int v=x*60+y-120;
    if ((!(x>23))and (x>0)and (y>0)and (!(y>59))and (v>0))
    {
        if (!(v>6*60))
        {
            cout <<"NO";
            v=25*60;
        }
        if (v<8*60)
        {
            cout <<"YES";
            v=25*60;
        }
        if (!(v>15*60))
        {
            cout <<"NO";
            v=25*60;
        }
        if (v<16.5*60)
        {
            cout <<"YES";
            v=25*60;
        }
        if (!(v>17*60))
        {
            cout <<"NO";
            v=25*60;
        }
        if (v<22*60)
        {
            cout <<"YES";
            v=25*60;
        }
        if (v<24.1)
        {
            cout <<"NO";
        }
    }
    else
    {
        cout << "error";
    }
}
