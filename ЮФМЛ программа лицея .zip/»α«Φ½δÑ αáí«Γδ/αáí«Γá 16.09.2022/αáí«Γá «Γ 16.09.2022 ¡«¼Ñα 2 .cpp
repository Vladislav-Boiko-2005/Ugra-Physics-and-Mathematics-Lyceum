#include <iostream>
using namespace std;
int main ()
{
    system ("chcp 1251>nul");
    float x,y,a,b,v,w,c,d;
    cin>>x>>y>>a>>b>>v>>w>>c>>d;
    if ((x>0)and (y>0)and (a>0) and (b>0) and (v>0) and (w>0) and (c>0) and (d>0))
    {
        //���������� kol1
        float min1=y;
        float max1=x;
        if (max1<y)
        {
            max1=y;
            min1=x;
        }
        float max2=a;
        float min2=b;
        if (max2<b)
        {
            min2=a;
            max2=b;
        }
        //cout << max1<<endl<<max2<<endl;
        int kol1=max1/max2;
        if (kol1>(min1/min2))
        {
            kol1=min1/min2;
        }
        //���������� kol2
        float min3=w;
        float max3=v;
        if (max3<w)
        {
            max3=w;
            min3=v;
        }
        float max4=c;
        float min4=d;
        if (max4<d)
        {
            min4=c;
            max4=d;
        }
        int kol2=min3/max4;
        if (kol2>(max3/min4))
        {
            kol2=max3/min4;
        }
        //cout << kol1<<endl<<kol2<<endl;
        if (kol1==kol2)
        {
            cout <<"���������";
        }
        else
        {
            if (kol1>kol2)
            {
                cout << "��";
            }
            else
            {
                cout << "������";
            }
        }
    }

    else
    {
        cout <<"error";
    }
}
