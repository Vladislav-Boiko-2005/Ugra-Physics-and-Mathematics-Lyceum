#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
    float x,y,a;
    cin>>x>>y>>a;
    int a2=a;
    //�������� �� ������� �
    if ((a-a2)==0)
    {
        float eps =0.0001;
        float r1= abs(a-x);
        float r2= abs(a-y);
        if (abs(r1-r2)<eps)
        {
            cout << x<<endl << y;
        }
        else
        {
            if (r1<r2)
            {
                cout << x;
            }
            else
            {
                cout << y;
            }
        }
    }
    else
    {
        cout<<"error";
    }
    return 0;
}
