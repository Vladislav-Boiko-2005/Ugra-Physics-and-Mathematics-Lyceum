#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
    float x,y;
    cin>> x>>y;
    if (!(y<0))
    {
        if ((abs (x))<1)
        {
            if (!(y<abs(x)))
            {
                cout << "Yes";
            }
            else
            {
                cout <<"No";
            }
        }
        else
        {
            if (!(y<1))
            {
                cout <<"Yes";
            }
            else
            {
                cout << "No";
            }
        }
    }
    else
    {
        cout <<"No";
    }
}
