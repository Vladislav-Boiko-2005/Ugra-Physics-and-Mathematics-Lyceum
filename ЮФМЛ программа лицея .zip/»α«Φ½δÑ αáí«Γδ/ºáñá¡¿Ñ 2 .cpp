#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int c, d;
	cin >> c >> d;
	int b, a;
	b = d / c;
	a = c / b;
	int f = pow(a, 5) * pow(b, 7);
	int g = pow(a, 5) * pow(b, 8);
	cout << f << endl << g;
	return 0;
}