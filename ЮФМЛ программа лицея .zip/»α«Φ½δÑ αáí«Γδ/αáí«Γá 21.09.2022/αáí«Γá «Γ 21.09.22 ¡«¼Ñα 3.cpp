#include <iostream>
using namespace std;
int main ()
{
    system ("chcp 1251>nul");
    int vvod1,vvod2 ;
    cin >> vvod1>>vvod2;
    int a2=vvod1/100;
    int a1=(vvod1-a2*100)/10;
    int a0=vvod1-a2*100-a1*10;
    int b1=vvod2/10;
    int b0=vvod2-b1*10;
    int raz=0;
    if (a0>=b0)
    {
        raz=a0-b0;
    }
    else
    {
        raz=10+a0-b0;
        a1=a1-1;
        if (a1==-1)
        {
            a2=a2-1;
            a1=a1+1;
        }
    }
    if (a1>=b1)
    {
        raz=(a1-b1)*10+raz;
    }
    else
    {
        a2=a2-1;
        raz=(10+a1-b1)*10+raz;
    }
    raz=a2*100+raz;
    //������� ���������
    int colelem=0;
    if (raz/100!=0)
    {
        colelem=3;
    }
    else
    {
        if (raz/10!=0)
        {
            colelem=2;
        }
    }
    cout << raz<<endl<<colelem;
    return 0;
}
