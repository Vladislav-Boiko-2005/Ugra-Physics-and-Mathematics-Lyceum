#include <iostream>
using namespace std;
int main ()
{
    int a1,a2,a3;
    int b1,b2,b3;
    cin >>a1>>a2>>a3>>b1>>b2>>b3;
    if (a3<b3)
    {
        cout<<1;
    }
    else
    {
        if (a3>b3)
        {
            cout<<2;
        }
        if (a3==b3)
        {
            if (a2<b2)
            {
                cout<<1;
            }
            else
            {
                if (b2>a2)
                {
                    cout<<2;
                }
                if(a2==b2)
                {
                    if (a1<b1)
                    {
                        cout<<1;
                    }
                    if (a1>b1)
                    {
                        cout<<2;
                    }
                    if (a1==b1)
                    {
                        cout<<3;
                    }
                }
            }
        }
    }
    return 0;
}
