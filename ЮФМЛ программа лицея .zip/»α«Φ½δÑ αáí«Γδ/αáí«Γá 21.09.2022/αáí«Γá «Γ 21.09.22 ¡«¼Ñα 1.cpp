#include <iostream>
using namespace std;
int main ()
{
    system ("chcp 1251>nul");
    float x1,y1,x2,x3,y3,x4;
    cin >>x1>>y1>>x2>>x3>>y3>>x4;
    float per=y1;
    if (y1-y3>y3-y1)
    {
        per=y3;
    }
    // ������ s1
    if (x1<=x3)
    {
        if (x2<x3)
        {
            cout <<0;
        }
        else
        {
            float pl =(x2-x3)*per;
            cout << pl << endl;
        }
    }
    else
    {
        if (x4<x1)
        {
            cout << 0;
        }
        else
        {
            float pl =(x4-x1)*per;
            cout << pl<<endl;
        }
    }
    return 0;
}
