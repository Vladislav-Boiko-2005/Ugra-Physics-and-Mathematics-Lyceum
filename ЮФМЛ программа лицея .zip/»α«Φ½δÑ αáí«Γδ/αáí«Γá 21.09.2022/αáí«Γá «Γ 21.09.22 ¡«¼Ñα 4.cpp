#include <iostream>
using namespace std;
int main ()
{
    int k;
    cin >>k;
    if (k<11)
    {
        int n =k-1;
    }
    else
    {
        int des=((k-12)/20)+1;
        int n =(k-12)%20;
        if (n%2!=0)
        {
            cout << des <<endl;
        }
        else
        {
            n=n/2;
            cout <<n<<endl;
        }
    }
}
