#include <iostream>
using namespace std;
int main()
{
	float c,d;
	cin >> c>> d;
	float m =c*d;
	m=m*m;
	float f =m*c;
	float g=f*(d/c);
	cout << f<<endl<< g;
	return 0;
}
