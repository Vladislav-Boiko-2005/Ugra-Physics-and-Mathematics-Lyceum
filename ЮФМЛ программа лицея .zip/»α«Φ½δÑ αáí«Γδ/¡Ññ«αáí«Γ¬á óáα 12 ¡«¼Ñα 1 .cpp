#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
    if (1>0)
    {
        float x1,y1,x2,x3,y3,x4;
        cin >>x1>>y1>>x2>>x3>>y3>>x4;
        //������ ������ s1
        if (!(x1<x3))
        {
            if (x2<x3)
            {
                cout <<0;
            }
            else
            {
                float per =(x2-x3)*(abs(y1-y3));
                cout << per;
            }
        }
        else
        {
            if (x4<x1)
            {
                cout << 0;
            }
            else
            {
                float per =(x4-x1)*(abs(y1-y3));
                cout << per;
            }
        }
    }
    else
    {
        cout << "error";
    }
    return 0;
}
