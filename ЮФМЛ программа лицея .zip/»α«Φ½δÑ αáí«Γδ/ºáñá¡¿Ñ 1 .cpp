#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int a, b, u;
	cin >> a >> b >> u;
	float h = tan(u) * ((a - b) / 2);
	float pl = h * ((a + b) / 2);
	float r = exp(pl / 3.14);
	cout << r;
	return 0;
}