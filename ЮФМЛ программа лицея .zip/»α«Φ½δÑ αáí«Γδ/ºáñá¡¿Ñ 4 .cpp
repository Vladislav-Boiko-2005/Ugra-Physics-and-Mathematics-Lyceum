#include <iostream>
#include <string>
using namespace std;
int main()
{
	string h;
	cin >> h;
	char p5 = h[0];
	char p1 = h[4];
	char p2 = h[1];
	char p3 = h[2];
	char p4 = h[3];
	cout << p1 << p2<< p3<< p4<< p5;
	return 0;
}