#include <iostream>
using namespace std;
int main()
{
	int a;
	cin>>a;
	int a1=a/10000*10000;
	int ap=a-(a/10)*10;
	a=a-a1-ap;
	int a3=a1/10000;
	int a4=ap*10000;
	a=a+a3+a4;
	cout << a;
	return 0;
}
