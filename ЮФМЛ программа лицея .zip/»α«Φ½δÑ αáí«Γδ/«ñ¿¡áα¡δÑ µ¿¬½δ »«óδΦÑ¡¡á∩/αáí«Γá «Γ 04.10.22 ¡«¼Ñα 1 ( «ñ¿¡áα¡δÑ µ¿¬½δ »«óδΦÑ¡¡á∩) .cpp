#include <iostream>
using namespace std;
int step (int n)
{
    int step=1;
    for (int i=0;i<n;i++)
    {
        step=step*2;

    }
    return 0;
}
int main ()
{
    float n;
    cin>>n;
    float step2=step(n);
    float rez=n/(2*n+1);
    for (float i=n;i>0;i--)
    {
        //float n1=i;
        rez=step2+(i/rez);
        step2=step2/2;
        //cout<<rez<<endl;
    }
    int n1=n;
    if (n1%2!=0)
    {
        rez=1/rez;
    }
    cout<<rez<<endl;
}
