#include <iostream>
using namespace std;
int main ()
{
    int vvod;
    cin >>vvod;
    int step10=10*10*10*10*10;
    int novh=0;
    int n=vvod;
    for (int i=5;i>0;i--)
    {
        //int n=vvod;
        int n1p=(vvod/(10*step10))*(step10*10);
        int n1m=(vvod/(step10/10))*(step10/10);
        n=(vvod-(vvod-n1p-n1m))/(step10/10);
        //cout<<n<<endl;
        vvod=vvod-n*step10/10;
        if (n!=0)
        {
            if(n%2==0)
            {
                n=n+1;
            }
            else
            {
                if(n%2!=0)
                {
                    n=n-1;
                }
            }
        }
        step10=step10/10;
        novh=novh+n*step10;
    }
    cout<<novh;
}
