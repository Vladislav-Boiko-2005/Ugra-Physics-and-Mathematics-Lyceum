#include <iostream>
using namespace std;
int chetcif1=0;
int funcs (int vvod)
{
    chetcif1=0;
    int d=1;
    //int chetcif1=0;
    int cheti=0;
    while ((vvod/d)>10)
    {
        d=d*10;
        cheti++;
        chetcif1++;
    }
    chetcif1++;
    cheti++;
    int bm=0;
    int summ=0;
    for (int i=0;cheti>i;i++)
    {
        int n1=(vvod-bm)/d;
        bm=(bm+n1*d);
        //cout<<bm<<endl;
        d=d/10;
        summ=summ+n1;
        //cout<<n1<<endl;
        //cout<<summ<<endl;
    }
    return summ;
}
int main ()
{
    int chetcif=0;
    int colvo=0;
    int n;
    cin>>n;
    while (n>10)
    {
        int r;
        n=funcs(n);
        chetcif=chetcif+chetcif1;
        //cout<<chetcif<<endl;
    }
    //cout<<n<<endl;
    if ((n==2)or(n==4)or(n==8))
    {
        cout<<"yes"<<endl;
    }
    else
    {
        cout<<"no"<<endl;
    }
    cout<<chetcif+1<<endl;
    return 0;
}
