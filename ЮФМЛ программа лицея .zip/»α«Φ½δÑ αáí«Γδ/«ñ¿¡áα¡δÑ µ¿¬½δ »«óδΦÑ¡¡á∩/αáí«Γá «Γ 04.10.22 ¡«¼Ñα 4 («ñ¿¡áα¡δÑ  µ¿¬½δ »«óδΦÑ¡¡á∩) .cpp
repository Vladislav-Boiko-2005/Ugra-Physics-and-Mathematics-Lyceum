#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
    int n;
    cin>>n;
    float e=0.0001;
    float sum=0;
    for(int i=1;i<n+1;i++)
    {
        float a=pow(-1,i+1)/(i*(i+1));
        if (a>=e)
        {
            sum=sum+a;
        }
    }
    cout<<sum<<endl;
}
