#include <iostream>
using namespace std;
int main ()
{
    int n;
    cin >>n;
    if ((n<50)and(n>2))
    {
        int sum=0;
        for (int i=0;i<n;i++)
        {
            float vvod=0;
            cin>>vvod;
            int vvodc=vvod;
            if (vvod==vvodc)
            {
                sum=sum+vvod;
            }
        }
        cout<<sum;
    }
    else
    {
        cout<<"error";
    }
}
