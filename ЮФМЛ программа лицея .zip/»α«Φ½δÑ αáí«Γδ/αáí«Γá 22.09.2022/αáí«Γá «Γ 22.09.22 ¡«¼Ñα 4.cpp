#include <iostream>
using namespace std;
int main ()
{
    float b;
    cin>>b;
    int chet=0;
    int sum =0;
    while (b>sum)
    {
        sum=sum+10;
        chet++;
    }
    cout <<chet;
}
