#include <iostream>
#include <iomanip>
using namespace std;
float func (float i,float x)
{
    float step=x;
    for (int i1=0;i1<i;i1++)
    {
        step=step*step;
    }
    float rez=1+step;
    for (int i1=0;i1<i;i1++)
    {
        rez=(1+step)*rez;
    }
    return rez;
}
int main ()
{
    int n;
    float x;
    cin>>n>>x;
    float sum=0;
    for (int i=0;i<n;i++)
    {
        sum=sum+(1/func(i,x));
    }
    cout <<fixed<<setprecision (3)<<sum;
}

