#include <iostream>
using namespace std;
int step10 (int s)
{
    int step=1;
    for (int i=0;i<s;i++)
    {
        step=step*10;
    }
    return step;
}
int main ()
{
    long int n;
    cin>>n;
    int mins=10;
    int vth=0;
    for (int i=0;i<10;i++)
    {
        int sim=n/step10(9-i);
        //cout<<sim<<endl;
        if (sim<mins)
        {
            mins=sim;
        }
        vth=sim*step10(9-i);
        //cout<<vth<<endl;
        n=n-vth;
        //cout<<n<<endl;
    }
    cout <<mins;
    return 0;
}
