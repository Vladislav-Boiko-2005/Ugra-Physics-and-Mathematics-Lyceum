#include <iostream>
using namespace std;
int main ()
{
    int a=1;
    int b=1;
    int n;
    cin >>n;
    for (int i=0;i<(n-1);i++)
    {
        a=3*b+2*a;
        b=2*a+b;
    }
    cout<< a;
    return 0;
}
