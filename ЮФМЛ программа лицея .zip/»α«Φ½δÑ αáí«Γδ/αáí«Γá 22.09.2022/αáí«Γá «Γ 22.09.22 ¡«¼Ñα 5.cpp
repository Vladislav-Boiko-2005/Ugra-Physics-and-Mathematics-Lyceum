#include <iostream>
using namespace std;
int main ()
{
    float a,x,p,y;
    cin >>a>>x>>p>>y;
    float pl=a;
    int chetg=0;
    while (1.3*a>=pl)
    {
        pl=pl+(p/100*pl);
        chetg++;
    }
    chetg=chetg+1;
    cout<<chetg;
}
