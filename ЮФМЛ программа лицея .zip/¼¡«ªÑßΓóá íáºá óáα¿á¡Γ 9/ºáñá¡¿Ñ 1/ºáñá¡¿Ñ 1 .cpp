#include <iostream>
#include <set>
int main ()
{
    int k;
    std::cin>>k;
    std::set <char> mn1;
    size_t chet_h=0;
    for (size_t i=0;i<100;i++)
    {
        char vvod;
        std::cin>>vvod;
        if ((vvod>'E'-1)&&(vvod<'P'+1))
        {
            mn1.insert(vvod);
            chet_h++;
        }
        if (chet_h==k)
        {
            break;
        }
    }
    int razm_mn_2='N'-'H'+1;
    if (mn1.size()<=razm_mn_2)
    {
        for (auto i=mn1.begin();i!=mn1.end();i++)
        {
            std::cout<<*i<<'\n';
        }
    }
    else
    {
        std::cout<<0;
    }
}
