#include<iostream>
#include<set>
int main ()
{
    int n;
    int m;
    std::cin>>n>>m;
    std::set<int> st;
    for (int i=0;i<n*m;i++)
    {
        int vvod;
        std::cin>>vvod;
        st.insert(vvod);
    }
    std::cout<<st.size();
}
