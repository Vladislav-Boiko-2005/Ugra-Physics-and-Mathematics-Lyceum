#include <iostream>
#include <cmath>
#include <set>
void zifr (int a, std::set<int>&simvol1, std::set<int>&simvol2)
{
    while (a>0)
    {
        int n=a%10;
        //1std::cout<<n<<'\n';
        if (simvol2.find (n)==simvol2.end())
            {
                simvol1.insert(n);
            }
        a/=10;
    }
    return ;
}
int main ()
{
    int a_max=pow(10,10);
    int a_min=pow(10,1);
    int a;
    std::cin>>a;
    int osn_sistem=5;
    if ((a>a_min)&&(a<a_max))
    {
        int ost_del=a;
        int nepol_hastnoe=a;
        std::set<int> zifr_2;
        while(nepol_hastnoe>0)
        {
            ost_del=nepol_hastnoe%osn_sistem;
            zifr_2.insert(ost_del);
            nepol_hastnoe=nepol_hastnoe/osn_sistem;
            //std::cout<<ost_del<<'\n'<<nepol_hastnoe<<'\n';
        }
        std::set<int> zifr_1;
        zifr(a,zifr_1,zifr_2);
        if (zifr_1.begin()==zifr_1.end())
        {
            std::cout<<0;
            return 0;
        }
        for (auto i=zifr_1.begin();i!=zifr_1.end();i++)
        {
            std::cout<<*i<<' ';
        }
        std::cout<<'\n';
        return 0;
    }
    else
    {
        std::cout<<"Error";
        return 0;
    }
}
