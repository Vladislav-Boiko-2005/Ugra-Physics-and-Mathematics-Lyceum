#include <iostream>
using namespace std;
int main ()
{
    int n;
    cin>>n;
    char mas[n];
    for (int i=0;i<n;i++)
    {
        char vvod;
        cin>>vvod;
        mas[i]=vvod;
    }
    int maxh=-1;
    for (int i=0;i<n;i++)
    {
        if ((int(mas[i])%2==0)&&(int (mas[i])>maxh))
        {
            maxh=int (mas[i]);
        }
    }
    if (maxh==-1)
    {
        cout<<"No";
        return 0;
    }
    cout<<char(maxh)<<endl<<maxh;
    return 0;
}
