#include <iostream>
#include <string>
#include <cstdlib>
using namespace std;
int main ()
{
    system ("chcp 1251>nul");
    string st="������";
    st.erase(st.size()-1);
    st=st.substr(1);
    cout<<st;
}
