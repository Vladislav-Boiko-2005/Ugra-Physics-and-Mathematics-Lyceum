#include <iostream>
#include <string>
using namespace std;
int main ()
{
    string st;
    cin>>st;
    int flag =0;
    for (int i=0;i<st.size()-1;i++)
    {
        if (st[i+1]<=st[i])
            flag++;
    }
    if (flag>0)
    {
        cout<<"No";
        return 0;
    }
    cout<<"Yes";
    return 0;
}
