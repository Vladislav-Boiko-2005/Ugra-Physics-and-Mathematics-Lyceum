#include <iostream>
#include <string>
using namespace std;
int main ()
{
    string vvod;
    cin>>vvod;
    int flag=0;
    for (int i=0;i<(vvod.size())/2;i++)
    {
        if (vvod[i]!=vvod[vvod.size()-1-i])
            flag++;
    }
    if (flag==0)
    {
        cout<<"Yes";
        return 0;
    }
    else
    {
        cout<<"No";
        return 0;
    }
}
