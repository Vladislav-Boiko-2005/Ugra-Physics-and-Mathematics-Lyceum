#include <iostream>
using namespace std;
int main ()
{
    int n;
    cin>>n;
    char mas[n];
    for (int i=0;i<n;i++)
    {
        char vvod;
        cin>>vvod;
        mas[i]=vvod;
        //cout<<int (mas[i]);
    }
    int chet=0;
    for (int i=0;i<n-1;i++)
    {
        if ((int (mas[i])%2==0)&&(int (mas[i+1])-int (mas[i])==2))
            chet++;
    }
    cout<<chet;
}
