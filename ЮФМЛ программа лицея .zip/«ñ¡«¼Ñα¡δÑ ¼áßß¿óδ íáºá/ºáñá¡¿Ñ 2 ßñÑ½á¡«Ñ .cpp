#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    vector <int> vect;
    system ("chcp 1251>nul");
    int flag=0;
    for (int i=0;i<20;i++)
    {
        int vvod;
        cin>>vvod;
        if ((vvod>-1)&&(vvod<10000))
        {
            if ((vvod%4==0)&&((vvod/100)>0)&&((vvod/100)<10))
            {
                vect.push_back(vvod);
                flag++;
            }
        }
        else
        {
            cout<<"error";
            return 0;
        }
    }
    if (flag>0)
    {
        int min_el=vect[0];
        for (int i=0;i<vect.size();i++)
        {
            if (min_el>vect[i])
            {
                min_el=vect[i];
            }
        }
        cout<<min_el;
    }
    else
    {
        cout<<"����� ��������� ���";
    }
}
