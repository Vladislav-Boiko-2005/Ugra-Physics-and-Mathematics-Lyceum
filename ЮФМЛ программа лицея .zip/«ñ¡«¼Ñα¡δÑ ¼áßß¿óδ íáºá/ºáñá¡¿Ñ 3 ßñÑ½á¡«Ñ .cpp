#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    vector <int> vect;
    for (int i=0;i<12;i++)
    {
        int vvod;
        cin>>vvod;
        if ((vvod>-31)&&(vvod<41))
        {
            vect.push_back(vvod);
        }
        else
        {
            cout<<"error";
            return 0;
        }
    }
    int chet=0;
    for (int i=0;i<vect.size();i++)
    {
        if (vect[i]<0)
        {
            chet++;
            if (chet==3)
            {
                cout<<i;
                return 0;
            }
        }
    }
    cout<<-1;
}
