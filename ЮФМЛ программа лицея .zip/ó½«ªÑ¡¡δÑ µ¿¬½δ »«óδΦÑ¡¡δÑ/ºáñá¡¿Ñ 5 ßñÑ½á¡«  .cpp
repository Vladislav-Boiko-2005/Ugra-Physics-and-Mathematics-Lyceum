#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
    int n,m;
    cin>>n>>m;
    int a=3;
    int b=4;
    int c=5;
    int a1=2*n+1;
    int b1=2*n*n+2*n;
    int c1=2*n*n+2*n+1;
    float crat_a=float(a1/a);
    float crat_b=float(b1/b);
    float crat_c=float(c1/c);
    float epc=0.00001;
    if ((fabs(crat_a-crat_b)>epc)&&(fabs(crat_a-crat_c)>epc))
    {
        cout<<"pifagor 3 ";
    }
    else
    {
        cout<<"no pifagor 3";
    }
}
