#include <iostream>
using namespace std;
int main ()
{
    for (int i1=1;i1<10;i1++)
    {
        for (int i2=0;i2<10;i2++)
        {
            for (int i3=0;i3<10;i3++)
            {
                if ((i1!=i2)||(i2!=i3)||(i1!=i3))
                {
                    int otv=i1*100+i2*10+i3;
                    cout<<otv<<endl;
                }
            }
        }
    }
}
