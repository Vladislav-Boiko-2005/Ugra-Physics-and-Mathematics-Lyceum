#include <iostream>
#include <vector>
using namespace std;
int main ()
{
    vector <int> vect;
    vect.push_back(2);
    for (int i=3;i<1001;i++)
    {
        bool flag=0;
        for (int j=0;j<vect.size();j++)
        {
            if (i%vect[j]==0)
            {
                flag++;
            }
        }
        if (flag==0)
        {
            vect.push_back(i);
        }
    }
    for (int i=0;i<vect.size();i++)
    {
        cout<<vect[i]<<endl;
    }
}
