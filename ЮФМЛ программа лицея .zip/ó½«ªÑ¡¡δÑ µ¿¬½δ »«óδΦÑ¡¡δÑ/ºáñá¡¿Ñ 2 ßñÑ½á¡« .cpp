#include <iostream>
#include <cmath>
using namespace std;
int main ()
{
    int a,b;
    cin>>a>>b;
    for (int i=a;i<b;i++)
    {
        int maxdel=sqrt(i);
        int kol =0;
        if (maxdel*maxdel==i)
        {
            kol++;
        }
        for (int j=2;j<maxdel;j++)
        {
            if (i%j==0)
            {
                kol=kol+2;
                //cout<<j<<' '<<i/j<<' '<<"kol"<<' '<<kol<<' ';
            }
        }
        //cout<<'\n';
        if (kol==4)
        {
            cout<<i<<' ';
        }

    }
}
