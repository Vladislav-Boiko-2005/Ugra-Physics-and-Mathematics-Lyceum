#include <iostream>
#include <set>
using namespace std;
int main ()
{
    int k;
    int m;
    cin>>k>>m;
    set<int> pros;
    pros.insert(1);
    set<int> sostav;
    for (int elem=2;elem<m;elem++)
    {
        if (sostav.find(elem)==sostav.end())
        {
            pros.insert(elem);
            int ind=2;
            while (elem*ind<m)
            {
                sostav.insert(elem*ind);
                ind++;
            }
        }
    }
    int chetlih=0;
    for (auto i:pros)
    {
        if (i>k)
        {
            int kol_h=pros.size()-chetlih;
            cout<<kol_h<<'\n';
            break;
        }
        chetlih++;
    }
    chetlih=0;
    for (auto i:sostav)
    {
        if (i>k)
        {
            int kol_h=sostav.size()-chetlih;
            cout<<kol_h<<'\n';
            break;
        }
        chetlih++;
    }
    return 0;
}
