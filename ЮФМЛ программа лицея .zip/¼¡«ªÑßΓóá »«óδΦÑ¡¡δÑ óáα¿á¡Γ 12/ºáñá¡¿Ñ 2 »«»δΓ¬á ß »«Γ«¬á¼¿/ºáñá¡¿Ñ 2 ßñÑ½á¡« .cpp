#include <iostream>
#include <set>
using namespace std;
int main ()
{
    int k;
    cin>>k;
    multiset <int> Sort_set;
    int k_min=1;
    int k_max=20;
    if ((k<=k_min)||(k>=k_max))
    {
        cout<<"Error"<<'\n';
        return 0;
    }
    for (int i=0;i<k;i++)
    {
        int x;
        cin>>x;
        int x_min=1;
        int x_max=5;
        if ((x<=x_min)||(x>=x_max))
        {
            cout<<"Error"<<'\n';
            return 0;
        }
        for (int j=0;j<x;j++)
        {
            int Sort;
            cin>>Sort;
            int s_min=0;
            int s_max=8;
            if ((Sort<=s_min)||(Sort>=s_max))
            {
                cout<<"Error"<<'\n';
                return 0;
            }
            Sort_set.insert(Sort);
        }
    }
    Sort_set.insert(1000000);
    int chet_povtor=0;
    int proh=0;
    bool flag=1;
    for (auto i:Sort_set)
    {
        if (proh==i)
        {
            chet_povtor++;
        }
        else
        {
            if (chet_povtor>=k/2)
            {
                cout<<proh<<' ';
                flag=0;
            }
            chet_povtor=1;
        }
        proh=i;
    }
    if (flag)
    {
        cout<<"No"<<' '<<'\n';
        return 0;
    }
    cout<<'\n';
    return 0;
}
