#include <iostream>
#include <set>
using namespace std;
int main ()
{
    multiset<int> set_sort;
    int k;
    cin>>k;
    int k_min=1;
    int k_max=20;
    if ((k<k_min)||(k>k_max))
    {
        cout<<"Eror"<<'\n';
        return 0;
    }
    for (int i=0;i<k;i++)
    {
        int x;
        cin>>x;
        int x_min=1;
        int x_max=5;
        if ((x<x_min)||(x>x_max))
        {
            cout<<"Eror"<<'\n';
            return 0;
        }
        for (int j=0;j<x;j++)
        {
            int sort_zvet;
            cin>>sort_zvet;
            int sort_min=1;
            int sort_max=5;
            if ((sort_zvet<sort_min)||(sort_zvet>sort_max))
            {
                cout<<"Eror"<<'\n';
                return 0;
            }
            set_sort.insert(sort_zvet);
        }
    }

    for (auto i=set_sort.begin();i!=set_sort.end();i++)
    {
        cout<<*i<<' ';
    }
    cout<<'\n'<<'\n';
    int chet_pov=1;
    bool flag=0;
    for (auto i=set_sort.begin();i!=set_sort.end();i++)
    {
        //cout<<*i<<' ';
        auto sled_i=++i;
        i--;
        //cout<<*i<<' '<<*sled_i<<'\n';
        if (*i==*sled_i)
        {
            chet_pov++;
        }
        else
        {
            //cout<<chet_pov<<' ';
            if (chet_pov>=k/2)
            {
                cout<<*i<<' ';
                flag++;
            }
            chet_pov=1;
        }
    }
    if (flag==0)
    {
        cout<<"No"<<'\n';
    }
    return 0;
}
