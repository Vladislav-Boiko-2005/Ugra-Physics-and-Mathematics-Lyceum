#include<iostream>
#include<set>
#include<string>
int main ()
{
    int k;
    std::cin>>k;
    for (int i=0;i<k;i++)
    {
        std::string str;
        getline(std::cin,str);
        int j=0;
        while ((str[j]==' ')&&(j<str.size()))
        {
            j++;
        }
        int sort_roz=0;
        while ((str[j]!=' ')&&(j<str.size()))
        {
            sort_roz=sort_roz*10+(str[j]-'0');
            std::cout<<sort_roz<<' ';
        }
        for (int j=0;j<str.size();j++)
        {
        }
    }
}
