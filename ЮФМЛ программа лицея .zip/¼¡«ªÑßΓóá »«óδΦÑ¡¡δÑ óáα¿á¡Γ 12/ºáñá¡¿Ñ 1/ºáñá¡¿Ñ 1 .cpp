#include<iostream>
#include<string>
#include<set>
int main()
{
    system("chcp 1251>nul");
    std::string str;
    getline(std::cin,str);
    std:: set<char> st_str;
    for (int i=0;i<str.size();i++)
    {
        if ((str[i]>'�'-1)&&(str[i]<'�'+1))
        {
            st_str.insert(str[i]);
        }
    }
    for (auto i=st_str.begin();i!=st_str.end();i++)
    {
        std::cout<<*i<<' ';
    }
    std::cout<<'\n';
    return 0;
}
