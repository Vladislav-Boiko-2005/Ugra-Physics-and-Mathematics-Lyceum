#include <iostream>
#include <cmath>
struct point
{
    point (int x=0,int y=0,std::string name="O"):x(x),y(y),name(name)
    {
    }
    std::string name;
    void line (point*p2)
    {
        int delta_x=(this->x-p2->x);
        int delta_y=(this->y-p2->y);
        float raz=sqrtf((float)delta_x*delta_x+delta_y*delta_y);
        std::cout<<raz<<'\n';
    }
    void print ()
    {
        std::cout<<name<<' '<<x<<' '<<y<<'\n';
    }
    ~point()
    {
        std::cout<<"delete"<<' ';
    }
    int x;
    int y;
};
int main ()
{
    point p1={3,5};
    point p2;
    p2.line(&p1);
}
