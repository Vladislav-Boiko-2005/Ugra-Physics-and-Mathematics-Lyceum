#include <iostream>
#include <string>
#include <unordered_set>
#include <unordered_map>

struct ResposeData {
    bool Success;
    std::string Response;
};

class AccessControl {
public:
    AccessControl(int admin) : adminId(admin) {
        users[adminId] = "ADMIN";
    }

    bool IsUserExists(int userId) const {
        return users.find(userId) != users.end();
    }

    bool IsUserBanned(int userId) const {
        return bannedUsers.find(userId) != bannedUsers.end();
    }

    bool IsUserAdmin(int userId) const {
        return users.at(userId) == "ADMIN";
    }

    bool IsUserModerator(int userId) const {
        return users.at(userId) == "MODERATOR";
    }

    bool IsUserAuthorized(int userId) const {
        return IsUserExists(userId) && !IsUserBanned(userId);
    }

    bool CanAddUser(int sender) const {
        return IsUserAdmin(sender);
    }

    bool CanBanUser(int sender, int user) const {
        return IsUserAdmin(sender) && IsUserExists(user) && !IsUserAdmin(user);
    }

    bool CanUnbanUser(int sender, int user) const {
        return IsUserAdmin(sender) && IsUserExists(user) && IsUserBanned(user);
    }

    bool CanGrantModeratorRole(int sender, int user) const {
        return IsUserAdmin(sender) && IsUserExists(user) && !IsUserAdmin(user);
    }

    bool CanGrantAdminRole(int sender, int user) const {
        return IsUserAdmin(sender) && IsUserExists(user) && !IsUserAdmin(user);
    }

private:
    int adminId;
    std::unordered_map<int, std::string> users;
    std::unordered_set<int> bannedUsers;
};

class Pausable {
public:
    Pausable() : chatStopped(false) {}

    bool IsChatStopped() const {
        return chatStopped;
    }

    void StopChat() {
        chatStopped = true;
    }

    void ResumeChat() {
        chatStopped = false;
    }

private:
    bool chatStopped;
};

class SystemBase : public AccessControl, public Pausable {
public:
    SystemBase(int admin) : AccessControl(admin), Pausable() {}

    ResposeData BanUser(int sender, int user) {
        if (!CanBanUser(sender, user)) {
            return {false, ""};
        }

        bannedUsers.insert(user);
        return {true, ""};
    }

    ResposeData UnBanUser(int sender, int user) {
        if (!CanUnbanUser(sender, user)) {
            return {false, ""};
        }

        bannedUsers.erase(user);
        return {true, ""};
    }

    ResposeData RegisterNewUser(int sender, int newUser) {
        if (!CanAddUser(sender)) {
            return {false, "only admin can register"};
        }

        if (IsUserExists(newUser)) {
            return {false, "already registered"};
        }

        users[newUser] = "USER";
        return {true, ""};
    }

    ResposeData GrantModeratorRole(int sender, int user) {
        if (!CanGrantModeratorRole(sender, user)) {
            return {false, ""};
        }

        users[user] = "MODERATOR";
        return {true, ""};
    }

    ResposeData GrantAdminRole(int sender, int user) {
        if (!CanGrantAdminRole(sender, user)) {

    users[user] = "ADMIN";
    return {true, ""};
}

ResposeData StopChat(int sender) {
    if (!IsUserAdmin(sender)) {
        return {false, "only admin can stop chat"};
    }

    StopChat();
    return {true, ""};
}

ResposeData ResumeChat(int sender) {
    if (!IsUserAdmin(sender)) {
        return {false, "only admin can resume chat"};
    }

    ResumeChat();
    return {true, ""};
}
};
int main ()
{
}
