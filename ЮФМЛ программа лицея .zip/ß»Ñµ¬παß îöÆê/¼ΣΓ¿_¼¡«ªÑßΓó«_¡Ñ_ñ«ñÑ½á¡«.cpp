#include <iostream>
#include <vector>
class Set
{
    public :
    int* Find (int n)
    {
        int* i=&vect[0];
        while (i!=&vect[vect.size()])
        {
            if (*i==n)
            {
                return i;
            }
            i++;
        }
        return i;
    }
    void Print ()
    {
        int* i=&vect[0];
        while (i!=&vect[vect.size()])
        {
            std::cout<<i<<' ';
            i++;
        }
        std::cout<<'\n';
    }
    Set ()
    {
    }
    ~ Set ()
    {
    }
    private :
    std::vector <int> vect={1,2,3,4,5,6,7}; // ������� ���������
};
int main ()
{
    Set p;
    std::cout<<p.Find (10)<<'\n';
    p.Print();
}
