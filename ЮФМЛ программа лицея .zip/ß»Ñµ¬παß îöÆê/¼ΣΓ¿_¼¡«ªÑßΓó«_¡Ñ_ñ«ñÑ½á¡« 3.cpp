#include <iostream>
#include <vector>
class Set
{
    public :
    int* Find (int n)
    {
        int* i=&vect[0];
        while (i!=&vect[vect.size()])
        {
            if (*i==n)
            {
                return i;
            }
            i++;
        }
        return i;
    }
    int* Find_bin (int n)
    {
        int* i_min=&vect[0];
        int* i=&vect[vect.size()/2];
        int* i_max=&vect[vect.size()-1];
        while (i_min!=i_max)
        {
            if (*i==n)
            {
                return i;
                break;
            }
            if (n>*i)
            {
                i_min=i;
                i=i+(1+i_max-i)/2;////+1 ��� ����������;
            }
            else
            {
                i_max=i;
                i=i-(1+i-i_min)/2;
            }
            //std::cout<<1<<' '<<*i_min<<' '<<*i_max<<'\n';
        }
        //int dop=i_max-&vect[0];
        //vect.insert(vect.begin()+dop,n);
        i=&vect[vect.size()];
        return i;
    }
    void Print ()
    {
        int* i=&vect[0];
        while (i!=&vect[vect.size()])
        {
            std::cout<<*i<<' ';
            i++;
        }
        std::cout<<'\n';
    }
    bool Insert (int n)
    {
        bool nal_in_set=1;
        if (vect.size()==0)
        {
            vect.push_back(n);
            return nal_in_set;
        }
        int i=0;
        while (n>vect[i]&&i<vect.size())
        {
            i++;
        }
        if (n==vect[i])
        {
            nal_in_set=0;
        }
        else
        {
            vect.insert(vect.begin()+i,n);
        }
        return nal_in_set;
    }
    Set ()
    {
    }
    ~ Set ()
    {
    }
    private :
    std::vector <int> vect; // ������� ���������
};
int main ()
{
    Set p;
    p.Insert(10);
    p.Print();
    p.Insert(10);
    p.Insert(9);
    p.Print();
}
