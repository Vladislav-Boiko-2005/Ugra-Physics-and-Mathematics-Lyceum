#include <iostream>
#include <windows.h>
#include <cstring>
#include <conio.h>


using namespace std;


int x=20;
int y=20;
char mas[20][20];

class snake
{
    public:
    snake ()
    {
        x_gol=1;
        y_gol=1;
    }
    void print_snake()
    {
        mas[y_gol][x_gol]=ch;
    }
    private:
    int x_gol;
    int y_gol;
    char ch='@';
};


void MoveXY (int x, int y)
{
    COORD pos;
    pos.X=x;
    pos.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}
int main ()
{
    for (int i=0;i<x;i++)
    {
        mas[0][i]='*';
        mas[y-1][i]='*';
    }
    for (int i=0;i<y;i++)
    {
        mas[i][0]='*';
        mas[i][x-1]='*';
    }
    for (int i=1;i<y-1;i++)
    {
        for (int j=1;j<x-1;j++)
            mas[i][j]=' ';
    }
    snake sn;
    while(true)
    {
        sn.print_snake();
        for (int i=0;i<y;i++)
        {
            for (int j=0;j<x;j++)
                cout<<mas[i][j]<<' ';
        cout<<'\n';
        }
        Sleep(80);
        MoveXY(0,0);
        char c=getch();;
        int vvod=int (c);
        if (vvod==27)
        {
            exit(0);
        }
    }
    /*for (int i=0;i<y;i++)
    {
        for (int j=0;j<x;j++)
            cout<<mas[i][j]<<' ';
        cout<<'\n';
    }
    cout<<'\n';*/
}
