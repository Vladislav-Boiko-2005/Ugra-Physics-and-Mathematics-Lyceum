#include <iostream>
#include <windows.h>
#include <cstring>
#include <conio.h>
#include <random>
#include <time.h>
#include <vector>
using namespace std;



int line_to_x=25;
int line_to_y=25;
char mas[25][25];


void MoveXY (int x, int y)
{
    COORD pos;
    pos.X=x;
    pos.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}




void create_pole ()
{
    MoveXY(0,0);
    for (int i=0;i<line_to_x;i++)
    {
        mas[0][i]='#';
        mas[line_to_y-1][i]='#';
    }
    for (int i=0;i<line_to_y;i++)
    {
        mas[i][0]='#';
        mas[i][line_to_x-1]='#';
    }
    for (int i=1;i<line_to_y-1;i++)
    {
        for (int j=1;j<line_to_x-1;j++)
            mas[i][j]=' ';
    }
}


void print ()
{
    for (int i=0;i<line_to_y;i++)
    {
        for (int j=0;j<line_to_x;j++)
        {
            cout<<mas[i][j]<<' ';
        }
        cout<<'\n';
    }
    MoveXY(0,0);
}


struct part_snake
{
    part_snake ()
    {
        this_x=1;
        this_y=1;
        proh_x=1;
        proh_y=1;
    }
    void moving_part( part_snake&pred)
    {
        proh_x=this_x;
        proh_y=this_y;
        this_x=pred.this_x;
        this_y=pred.this_y;
    }
    int this_x;
    int this_y;
    int proh_x;
    int proh_y;
};


class snake
{
public:
    snake()
    {
        vect.resize(3);
        part_snake n1;
        part_snake n2;
        part_snake n3;
        vect ={n1,n2,n3};
    }
private :
    vector <part_snake> vect;
};


int main ()
{
    while (true)
    {
        create_pole();
        print();
        char c=getch();;
        int vvod=int (c);
        if (vvod==27)
        {
            exit(0);
        }
        else
        {

        }

    }
}
