#include <iostream>
#include <vector>
template <typename T>
class Set
{
    private:
        std::vector <T> vect;
        T peremen;
    public:
        Set ()
        {
        }
};
int main ()
{
    class Set <int> p1;
}
