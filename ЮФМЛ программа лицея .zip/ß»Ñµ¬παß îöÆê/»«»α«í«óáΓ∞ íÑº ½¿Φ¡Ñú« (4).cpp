#include <iostream>
#include <windows.h>
#include <conio.h>
#include <random>
#include <time.h>
#include <vector>



using namespace std;



int line_to_x=25;
int line_to_y=25;
char mas[25][25];


void MoveXY (int x, int y)
{
    COORD pos;
    pos.X=x;
    pos.Y=y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),pos);
}




void create_pole ()
{
    MoveXY(0,0);
    for (int i=0;i<line_to_x;i++)
    {
        mas[0][i]='#';
        mas[line_to_y-1][i]='#';
    }
    for (int i=0;i<line_to_y;i++)
    {
        mas[i][0]='#';
        mas[i][line_to_x-1]='#';
    }
    for (int i=1;i<line_to_y-1;i++)
    {
        for (int j=1;j<line_to_x-1;j++)
            mas[i][j]=' ';
    }
}


void print ()
{
    for (int i=0;i<line_to_y;i++)
    {
        for (int j=0;j<line_to_x;j++)
        {
            cout<<mas[i][j]<<' ';
        }
        cout<<'\n';
    }
    MoveXY(0,0);
}


struct part_snake
{
    part_snake ()
    {
        this_x=1;
        this_y=1;
        proh_x=1;
        proh_y=1;
    }
    void moving_part( part_snake&pred)
    {
        proh_x=this_x;
        proh_y=this_y;
        this_x=pred.proh_x;
        this_y=pred.proh_y;
    }
    int this_x;
    int this_y;
    int proh_x;
    int proh_y;
};


class snake
{
public:
    snake()
    {
        vect.resize(3);
    }
    void moving_snake (int n);
    void print_snake();
    void kill_snake();
    vector <part_snake> vect;
private:
    char char_snake='*';
};


void snake::kill_snake()
{
    vect.resize(0);
    vect.resize(3);
    create_pole();
    print_snake();
    print();
}


void snake:: moving_snake (int n)
    {
        vect[0].proh_x=vect[0].this_x;
        vect[0].proh_y=vect[0].this_y;
        bool flag=0;
        switch (n)
        {
        case 72://///////////   ����
        {
            vect[0].this_y--;
            //vect[0].proh_y--;
            flag=1;
            break;
        }
        case 75 : ////////////////  �����
        {
            vect[0].this_x--;
            //vect[0].proh_x--;
            flag=1;
            break;
        }
        case 80://////////////////   ����
        {
            vect[0].this_y++;
            //vect[0].proh_y++;
            flag=1;
            break;
        }
        case 77: //////////////  ������
        {
            vect[0].this_x++;
            //vect[0].proh_x++;
            flag=1;
            break;
        }
        }
        if (mas[vect[0].this_y][vect[0].this_x]=='#')
        {
            kill_snake();
            return;
        }
        if (flag)
        {
            for (int i=1;i<vect.size();i++)
            {
                vect[i].moving_part(vect[i-1]);
                //cout<<vect[i].this_y<<' '<<vect[i].this_x<<'\n';
            }
            //Sleep(800);
        }
    }


void snake::print_snake()
{
    MoveXY(0,line_to_y+1);
    for (int i=0;i<vect.size();i++)
    {
        mas[vect[i].this_y][vect[i].this_x]=char_snake;
        //cout<<vect[i].this_x<<' '<<vect[i].this_y<<'\n';
        //cout<<n1.this_x<<' '<<n1.this_y<<'\n';
        //Sleep(800);
    }
    MoveXY(0,0);
    //vect[vect.size()-1].proh_x=' ';
    //vect[vect.size()-1].proh_y=' ';
}


int main ()
{
    create_pole();
    snake sn;
    sn.print_snake();
    print();
    int  c=getch();;
    while (true)
        {
        if (_kbhit())
        {
            c=getch();
        }
        else
        {
            if (c==27)
            {
                exit(0);
            }
            if (i>5)
            {

            }
            create_pole();
            sn.moving_snake(c);
            sn.print_snake();
            print();
            Sleep(200);
        }

    }
}
