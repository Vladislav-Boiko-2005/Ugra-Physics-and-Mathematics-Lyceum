#include <iostream>
#include <vector>
class Set
{
    public :
    int* Find (int n)
    {
        int* i=&vect[0];
        while (i!=&vect[vect.size()])
        {
            if (*i==n)
            {
                return i;
            }
            i++;
        }
        return i;
    }
    void Print ()
    {
        int* i=&vect[0];
        while (i!=&vect[vect.size()])
        {
            std::cout<<*i<<' ';
            i++;
        }
        std::cout<<'\n';
    }
    bool Insert (int n)
    {
        bool nal_in_set=1;
        int i=0;
        while (n>vect[i]&&i<vect.size())
        {
            i++;
        }
        if (n==vect[i])
        {
            nal_in_set=0;
        }
        else
        {
            vect.insert(vect.begin()+i,n);
        }
        return nal_in_set;
    }
    Set ()
    {
    }
    ~ Set ()
    {
    }
    private :
    std::vector <int> vect={1,2,3,4,5,6,7}; // ������� ���������
};
int main ()
{
    Set p;
    std::cout<<*p.Find (10)<<'\n';
    p.Print();
    std::cout<<p.Insert(0)<<'\n';
    p.Print();
}
