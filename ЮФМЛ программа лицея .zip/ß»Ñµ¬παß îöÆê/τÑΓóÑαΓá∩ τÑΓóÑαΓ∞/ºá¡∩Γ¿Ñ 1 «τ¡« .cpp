#include <iostream>
#include <string>


class person
{
    public:
    virtual std::string accupation () const =0;
};

class student : public person
{
    public:
    std::string accupation () const
    {
        return "student";
    }
};

class professor : public person
{
    public:
    std::string accupation () const
    {
        return "professor";
    }
};

 person * next_person (student & st, professor & prof)
 {
     int n;
     std::cin>>n;
     if (n>0)
     {
         return &prof;
     }
     else
     {
         return &st;
     }
 }
int main ()
{
    student stud;
    professor prof;
    person * p =next_person (stud, prof);
    std::cout<<p->accupation ();
}
