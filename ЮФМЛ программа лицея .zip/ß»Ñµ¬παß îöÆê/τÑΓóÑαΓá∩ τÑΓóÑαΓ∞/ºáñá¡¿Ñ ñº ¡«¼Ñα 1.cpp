#include <iostream>
#include <set>
#include <vector>


class AccessControl {
public:
 bool HasRole(int id, const std::string& roleName) const;
 //bool GrantRole(int id, const std::string& roleName);
 //bool RemoveRole(int id, const std::string& roleName);
 void RegisterRole(const std::string& roleName);
 std::set <std::string> set_roleName;
std:: pair <int, std::vector <std::string> > id_and_role;
};


void AccessControl :: RegisterRole(const std::string& roleName)
{
    if (set_roleName.find(roleName)==set_roleName.end())
    {
        set_roleName.insert(roleName);
    }
}


bool AccessControl :: HasRole(int id, const std::string& roleName) const
{
    auto eter = (id_and_role.find(id)).first();
    if (set_roleName.find(roleName)==set_roleName.end())
    {
        return 0;
    }
    for (int i=0;i<eter.second().size();i++)
    {
        if (eter.second()[i]==roleName)
        {
            return 1;
        }
    }
}

int main ()
{
    AccessControl p1;
    for (auto i :set_roleName)
    {
        std::cout<<i<<'\n';
    }
    //std::cout<<p1.<<'\n';
    std::cout<<"vse"<<'\n';
    p1.RegisterRole("Valera");
    p1.RegisterRole("Valera");
    for (auto i :set_roleName)
    {
        std::cout<<i<<'\n';
    }
}
