#include <iostream>
class Granny
{
public:
    int x;
};
class Mother
{
public:
    int y;
};
class Daugher:public Mother, public Granny
{
public:
    int z;
};
int main ()
{
    Daugher d;
    std::cout<<&d.x<<'\n'<<&d.y<<'\n'<<&d.z<<'\n';
}
