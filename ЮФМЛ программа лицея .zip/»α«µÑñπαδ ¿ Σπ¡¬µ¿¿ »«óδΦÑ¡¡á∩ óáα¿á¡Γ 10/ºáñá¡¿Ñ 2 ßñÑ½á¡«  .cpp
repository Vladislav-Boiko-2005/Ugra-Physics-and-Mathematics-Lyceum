#include <iostream>
#include <string>
#include <vector>
using namespace std;
void del (string vvod,string &s1,string &s2)
{
    int i=0;
    s1="";
    while (vvod[i]!='/')
    {
        s1=s1+vvod[i];
        i++;
    }
    vvod.erase(0,i+1);
    i=0;
    s2=vvod;
}
int nod (int a, int b)
{
    if (a%b==0)
    {
        return b;
    }
    else
    {
        nod( b,a%b);
    }
}
int str_to_int (string st)
{
    int h_int=0;
    for (int i=0;i<st.size();i++)
    {
        h_int=h_int*10+(int (st[i])-48);
    }
    return h_int;
}
int main ()
{
    string vvod1,vvod2;
    cin>>vvod1>>vvod2;
    string s1,s2,s3,s4;
    del(vvod1,s1,s2);
    del(vvod2,s3,s4);
    int h1=str_to_int(s1)*str_to_int(s3);
    int h2=str_to_int(s2)*str_to_int(s4);
    int krat=nod(h1,h2);
    h1=h1/krat;
    h2=h2/krat;
    cout<<h1<<' '<<h2<<endl;
}
