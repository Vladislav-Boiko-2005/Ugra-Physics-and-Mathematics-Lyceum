#include <iostream>
using namespace std;
int rec(int h,int a, int n)
{
    if (n==1)
        return a;
    rec(h,a+h,n-1);
}
int main ()
{
    int h,a,n;
    cin>>a>>h>>n;
    int a_n=rec(h,a,n);
    cout<<a_n<<endl;
}
