#include<iostream>
#include<string>
bool arifm (char vvod)
{
    if (int (vvod)>31&&int (vvod)<63)
    {
        if (int (vvod)>49)
        {
            if (int (vvod)!=58&&int (vvod)!=59)
                return 1;
        }
        else
        {
            if (int (vvod)!=44&&int (vvod)!=46)
                return 1;
        }
    }
    return 0;
}
std::string del (std::string& str)
{
    std::string str2="";
    for (int i=0;i<str.size();i++)
    {
        if (arifm(str[i]))
        {
            str2+=str[i];
            str.erase(i,1);
            i--;
        }
    }
    return str2;
}
int main ()
{
    std::string s1;
    std::cin>>s1;
    std::string s2=del(s1);
    if (s1=="")
    {
        std::cout<<"zero"<<'\n';
        if (s2=="")
        {
            std::cout<<"zero"<<'\n';;
        }
    }
    else if (s2=="")
    {
        std::cout<<"zero"<<'\n';
    }
    std::cout<<s1<<'\n'<<s2<<'\n';
}
