#include <iostream>
#include <string>
using namespace std;
int main()
{
    string v1;
    getline(cin,v1);
    string v2;
    v2=v1[0];
    for (int i=1;i<v1.size();i++)
        if (v1[i]!=' '&&v1[i]!=',')
        {
            v2.push_back(v1[i]);
        }
    for (int i=0;i<v2.size();i++)
        for (int j=0;j<v2.size()-1-i;j++)
        if (v2[j]>v2[j+1])
        {
            char pr=v2[j+1];
            v2[j+1]=v2[j];
            v2[j]=pr;
        }
    for (int i=0;i<v2.size()-1;i++)
    if (v2[i]!=v2[i+1])
        cout<<v2[i];
    cout<<endl;
    cout<<v1<<endl<<v2;
}
