#include <iostream>
#include <string>
using namespace std;
int main ()
{
    string vvod;
    cin>>vvod;
    for (int i=0;i<vvod.size();i++)
        for (int j=0;j<vvod.size()-i;j++)
        {
            if (vvod[vvod.size()-j-1]<vvod[vvod.size()-j])
            {
                char s=vvod[vvod.size()-j-1];
                vvod[vvod.size()-j-1]=vvod[vvod.size()-j];
                vvod[vvod.size()-j]=s;
            }
        }
    if (vvod[0]=='0')
    {
        cout<<0;
        return 0;
    }
    cout<<vvod;
    return 0;
}
