#include <iostream>
#include <string>
using namespace std;
int main ()
{
    string vvod1, vvod2;
    cin>>vvod1>>vvod2;
    for (int i=0;i<vvod1.size();i++)
        for (int j=0;j<vvod1.size()-i-1;j++)
        {
            if (vvod1[j+1]<vvod1[j])
            {
                char pr=vvod1[j];
                vvod1[j]=vvod1[j+1];
                vvod1[j+1]=pr;
            }
        }
    for (int i=0;i<vvod2.size();i++)
        for (int j=0;j<vvod2.size()-i-1;j++)
        {
            if (vvod2[j+1]<vvod2[j])
            {
                char pr=vvod2[j];
                vvod2[j]=vvod2[j+1];
                vvod2[j+1]=pr;
            }
        }
    vvod1=' '+vvod1;
    string st="";
     for (int i=0;i<vvod1.size()-1;i++)
     {
         if (vvod1[i]==vvod1[i+1]&&vvod1[i]!=vvod1[i-1])
         {
             for (int j=0;j<vvod2.size()-1;j++)
             {
                 if (vvod1[i]==vvod2[j]&&vvod1[i]==vvod2[j+1])
                    st=st+vvod1[i];
             }
         }
     }
     if (st=="")
     {
         cout<<"No";
         return 0;
     }
     cout<<st;
     return 0;
}
