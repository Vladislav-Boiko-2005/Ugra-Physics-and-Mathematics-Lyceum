#include <iostream>
#include <string>
using namespace std;
int main ()
{
    string vvod;
    getline(cin,vvod);
    if (vvod[vvod.size()-1]=='.')
        vvod[vvod.size()-1]=' ';
    int flag=0;
    for (int i=0;i<vvod.size();i++)
    {
            while (vvod[i]==' '&&i<vvod.size())
            {
                i++;
                flag++;
            }
            if (flag>0)
            {
                cout<<endl;
                flag=0;
            }
            cout<<vvod[i];
    }
    return 0;
}
