#include <iostream>
#include <string>
using namespace std;
int kol_8 (int h)
{
    int chet_8=0;
    while (h>0)
    {
        if (h%10==8)
            return 1;
        h=h/10;
    }
    return 0;
}
int main ()
{
    int n;
    cin>>n;
    int chet_h=0;
    for (int i=0;i<n;i++)
    {
        int vvod;
        cin>>vvod;
        chet_h=chet_h+kol_8(vvod);
    }
    cout<<chet_h;
}
