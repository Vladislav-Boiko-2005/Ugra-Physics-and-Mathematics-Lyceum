#include <iostream>
#include <string>
using namespace std;
int nod (int a, int b)
{
    while (a%b!=0)
    {
        int pr =a%b;
        a=b;
        b=pr;
    }
    return b;
}
int main()
{
    int a,b;
    cin>>a>>b;
    int nd=nod(a,b);
    cout<<nd;
}
