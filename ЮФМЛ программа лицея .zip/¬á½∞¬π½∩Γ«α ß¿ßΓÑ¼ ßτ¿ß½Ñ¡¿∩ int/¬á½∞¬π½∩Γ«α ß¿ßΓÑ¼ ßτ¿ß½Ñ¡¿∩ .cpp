#include <iostream>
using namespace std;

int to_10_sistem(int h_proh, int star_osnov)
{
    int new_h=0;
    int step=1;
    while (h_proh!=0)
    {
        if (h_proh%10>=star_osnov)
        {
            cout<<"error znah vvod new snah and new osnov"<<'\n';
            new_h=0;
            step=1;
            cin>>h_proh>>star_osnov;
        }
        new_h+=(h_proh%10)*step;
        step*=star_osnov;
        h_proh/=10;
    }
    return new_h;
}

int to_new_sistem (int h, int new_sistem)
{
    int step_10=1;
    int new_h=0;
    int cel_del=h;
    while(cel_del!=0)
    {
        new_h+=(cel_del%new_sistem)*step_10;
        step_10*=10;
        cel_del/=new_sistem;
    }
    return new_h;
}

int main ()
{
    int n, osnov1, osnov2;
    cin>>n>>osnov1>>osnov2;
    int ten_sistem=to_10_sistem(n,osnov1);
    int new_h=to_new_sistem(ten_sistem, osnov2);
    cout<<new_h<<'\n';
}
